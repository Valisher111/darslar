---
name: darslar-quiz
description: Write in-class quizzes for the Darslar teacher platform as JSON to paste into Quizzes → Paste from Claude. Use when the teacher asks for a Darslar quiz, "quiz JSON", "Darslar uchun test" or a quiz for a unit/lesson.
---

# Darslar quiz (JSON for "Paste from Claude")

The teacher uses the Darslar site (valisher111.github.io/darslar). You write the quiz; the teacher pastes your JSON into **Quizzes → Paste from Claude**. One quiz opens in the editor for checking; a list of quizzes is saved at once.

Talk to the teacher in Uzbek (Latin script), briefly, like a colleague. The quiz itself is in English.

## What a good quiz checks
- The **language** of the lesson that was taught: grammar, vocabulary, collocations, functional phrases, pronunciation rules. Never facts from a reading text ("What colour was Tom's car?").
- Default size: 15 items, 10–15 minutes: **10 MC + 3 TF + 1 gap + 1 match**, unless the teacher asks otherwise. At least half are MC.
- Source: the coursebook pages, Teacher's Book key or lesson plan the teacher gives you. If none is given, ask for the unit pages (PDF, photo or text) before writing. Do not invent the unit content.
- Distractors are plausible learner errors (e.g. *more early*, *I am agree*), never absurd.
- One clearly right answer per MC. No "all of the above", no trick wording.
- Each item gets a short `explain` (one rule, ≤ 120 characters) — students see it in their mistakes review.

## Format (exactly this)
```json
{"title": "Unit 5 - Food and Drink", "unit": "Unit 5", "duration_min": 10,
 "questions": [
  {"id":"q1","type":"mc","prompt":"I'd like ___ water, please.","options":["a","some","any","many"],"answer":1,"explain":"some — in offers and requests"},
  {"id":"q2","type":"tf","prompt":"'Menu' is a countable noun.","answer":true,"explain":"a menu, two menus"},
  {"id":"q3","type":"gap","prompt":"How ___ sugar do you take?","answer":"much","accept":["much"],"explain":"much + uncountable"},
  {"id":"q4","type":"match","prompt":"Match the halves","pairs":[["a cup","of tea"],["a slice","of bread"],["a bottle","of water"],["a bowl","of soup"]],"explain":"containers and portions"},
  {"id":"q5","type":"order","prompt":"Put the words in order","items":["Would","you","like","some","cake?"],"explain":"Would you like + noun?"}
 ]}
```
Rules the platform checks (a wrong item is refused):
- `title` like `Unit N - Topic`; `duration_min` 1–60; at most 40 questions; ids unique (`q1`, `q2`…).
- **mc**: 4 options (2–6 allowed), no duplicates, `answer` = index from 0. Question ≤ 120 characters, option ≤ 75.
- **tf**: `answer` is `true` or `false`; the statement is about a language rule or word meaning.
- **gap**: one blank `___`; `accept` lists every acceptable form (case, spaces and ' vs ’ are ignored).
- **match**: 4–6 pairs, left → right; the platform shuffles the right side.
- **order**: 4–7 pieces in the **correct** order; the platform shuffles them.
- Several quizzes at once: a JSON array `[ {...}, {...} ]`.

## How to answer
1. One line in Uzbek: what the quiz covers.
2. The JSON in one ```json block — nothing else inside the block.
3. One line: «Saytda Quizzes → Paste from Claude ga qo'ying.»
Before answering, check yourself: item count and mix, one right answer per MC, no duplicate options, English spelling, every `explain` filled.
